import { ShowcaseCard } from "./components/ShowcaseCard.jsx";

export function App() {
  return (
    <main className="demo-shell">
      <ShowcaseCard className="demo-card" />
    </main>
  );
}
