# Design QA: Good Fella ShowcaseCard

## Source truth

- Live source: `https://www.contentarchitecture.dev/`
- Selected element: `div#showcase > div.grid.grid-cols-1:nth-of-type(3) > a.group.block:nth-of-type(1)`
- Source idle capture: `../evidence/source-tablet-idle.png`
- Source hover capture: `../evidence/source-tablet-hover.png`
- Source desktop capture: `../evidence/source-desktop-idle.png`
- Source mobile page capture: `../../../2026-08-18T09-36-04-737Z/mobile-full.png`

## Implementation evidence

- React idle capture: `../evidence/implementation-tablet-idle.png`
- React hover capture: `../evidence/implementation-tablet-hover.png`
- React mobile capture: `../evidence/implementation-mobile-idle.png`
- Idle comparison: `../evidence/source-vs-react-idle.png`
- Hover comparison: `../evidence/source-vs-react-hover.png`

## Normalization

- Tablet/source state: 826 x 495 CSS px at device-pixel ratio 2.
- Both canvases use a 1652 x 929 backing bitmap and are compared at 826 x 495 output pixels.
- Mobile implementation: 358 x 231 CSS px inside the source's 390 px viewport padding model, with a 716 x 403 backing canvas at DPR 2.
- The source card is transparent. The faint repeating text behind the source card belongs to the parent showcase-section renderer and is intentionally excluded from this component boundary; the standalone demo uses the source section color `#232323` instead.

## Findings

No actionable P0, P1, or P2 mismatch remains.

- Fonts and typography: passed. The downloaded GeistMono variable font, 14–16 px fluid sizing, 1.25 line height, uppercase treatment, and text-mask overflow match.
- Spacing and layout rhythm: passed. The card fills its parent, the media is 16:9, the title gap is 12 px, and normalized card geometry is exactly 826 x 495.109 px.
- Colors and visual tokens: passed. Foreground is white and the demo/background token is `#232323`; the component root remains transparent like the source.
- Image quality and asset fidelity: passed. The real downloaded Good Fella AVIF is used locally with the recovered crop. The normalized hover-media comparison differs by approximately 1.58% RMSE, attributable to screenshot compositing/encoding.
- Copy and content: passed. The title, accessible canvas label, image alt text, destination, target, and rel attributes match the source.
- Idle state: passed. All 4,440 recovered luminance cells render through the original 120-column, 37-row, 64-level algorithm.
- Hover state: passed. Canvas opacity reaches 0 and image opacity reaches 1 through the recovered 500 ms easing.
- Touch state: passed by recovered runtime and implementation review. Coarse-pointer activation follows the source's viewport-center observer.
- Responsive state: passed. The implementation redraws from 826 px to 358 px with the expected 2x backing resolution and proportional 16:9 geometry.
- Accessibility and motion: passed. The link semantics, canvas role/label, descriptive image alt, new-tab safety attributes, and reduced-motion treatment are preserved.
- Browser console: passed on a clean final load with no component errors.

The full component is readable at the normalized comparison size, including title typography and media detail, so a separate focused-region comparison is not necessary.

## Comparison history

The first normalized idle and hover comparisons found no P0/P1/P2 component mismatch. The only visible background difference is the source parent section's decorative text renderer showing through the card's transparent surface; no component code was changed to absorb that out-of-scope parent asset.

final result: passed
