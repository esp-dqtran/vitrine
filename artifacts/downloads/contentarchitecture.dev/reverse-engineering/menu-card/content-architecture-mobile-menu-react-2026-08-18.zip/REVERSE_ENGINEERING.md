# Mobile menu reconstruction

This component was reconstructed from the downloaded site implementation, not inferred from a screenshot alone.

## Evidence used

- The live DOM established the semantic boundary, dimensions, ARIA state, link destinations, and open/closed structure.
- Computed styles established the 160 px panel, 6 px dither frame, typography, spacing, colors, borders, and responsive presentation.
- The downloaded JavaScript bundle established the state model and original behavior: open/closed React state, outside-click and Escape handling, 0.32 s menu animation, staggered link animation, reduced-motion handling, and current-link state.
- The original inline logo and captured Geist Mono font are reused as assets.
- The source screenshots in `../evidence/` are visual regression references only.

## Component inference

`MobileMenuCard` is the reusable boundary because its DOM, styling, state, and events form one cohesive unit. Link rows remain data rather than separate public components. `DitherFrame` and `AnnouncementMarquee` are small internal visual primitives with independent ownership.

The normalized model is recorded in [`ui-ir.json`](./ui-ir.json) before React generation. This preserves the distinction between source analysis and framework output.

## Intentional adaptation

The clean component does not retain the original site's route, CMS, or page-section observer dependencies. Those become the `links`, `currentKey`, and `onNavigate` API. The structure, styling, state transitions, accessibility behavior, and motion remain faithful to the observed source.
