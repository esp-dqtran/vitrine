import { MobileMenuCard } from "./components/MobileMenuCard.jsx";

export function App() {
  return (
    <main className="demo-shell">
      <MobileMenuCard
        onNavigate={(_link, event) => {
          event.preventDefault();
        }}
      />
    </main>
  );
}
